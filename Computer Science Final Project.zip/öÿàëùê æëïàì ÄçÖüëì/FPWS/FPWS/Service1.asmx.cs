﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using FPDAL;
using System.Data;

namespace FPWS
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Service1 : System.Web.Services.WebService
    {
        [WebMethod]
        public Manager[] AllManagers()
        {
            Manager[] mangers;
            DataTable dt = Manager.AllManager();
            mangers = new Manager[dt.Rows.Count];
            int i = 0;
            foreach (DataRow dr in dt.Rows)
            {
                mangers[i] = new Manager();
                mangers[i].Set_me((int)dr["ID"]);
                i++;
            }
            return mangers;
        }
        [WebMethod]
        public DataSet GetAllManagers()
        {
            return Manager.GetAllManagers();
        }
        [WebMethod]
        public Student[] MyStudents(string mail)
        {
            DataRow dr = oleDBhelper.fill("Select * From Teachers where Email='" + mail + "'").Tables[0].Rows[0];
            Student[] students = Teacher.MyStudents((int)dr["ID"]);
            return students;
        }
        [WebMethod]
        public Teacher[] MyTeachers(string mail)
        {
            DataRow dr = oleDBhelper.fill("Select * From Students where Email='" + mail + "'").Tables[0].Rows[0];
            Teacher[] teachers = Student.MyTeachers((int)dr["ID"]);
            return teachers;
        }
        [WebMethod]
        public void AddGuest(string name, string phone, string mail, string way)
        {
            Manager.AddGuest(name, mail, phone, way);
        }
        [WebMethod]
        public int Login(string mail, string password, string type)
        {
            DataRow dr = Manager.Login(mail, password, type);
            if (dr == null)
            {
                return 0;
            }
            return (int)dr["ID"];
        }
        [WebMethod]
        public DataSet ViewMeetings(int id, string type)
        {
            DataSet dl = oleDBhelper.fill("Select * From StudentTeacher where " + type + "=" + id);//שולף את כל הלימודים להם האדם רשום
            DataSet ds = new DataSet();//בונה סט נתונים ריק
            DataTable dt = new DataTable();//בונה טבלת נתונים ריקה
            DataColumn[] dcarr = new DataColumn[6];//בונה מערך של עמודות
            //בונה את העמודות
            dcarr[0] = new DataColumn("ID", int.Parse("1").GetType());
            dcarr[1] = new DataColumn("Student", "".GetType());
            dcarr[2] = new DataColumn("Teacher", "".GetType());
            dcarr[3] = new DataColumn("Subject", "".GetType());
            dcarr[5] = new DataColumn("Hour", "".GetType());
            dcarr[4] = new DataColumn("Date", "".GetType());
            for (int i = 0; i < 6; i++)//מוסיף את העמודות לטבלה
            {
                dt.Columns.Add(dcarr[i]);
            }
            foreach (DataRow dr in dl.Tables[0].Rows)//עובר על כל השורות שבהם האדם רשום
            {
                DataSet dm = oleDBhelper.fill("Select * From Meeting where StudTeach=" + dr["ID"]+ "and Happend='לא'");//מוציא סט של כל הפגישות של האדם לפי שורה אשר לא התרחשו
                foreach (DataRow dn in dm.Tables[0].Rows)//עובד על כל הפגישות לפי הלימודים האלה
                {
                    Meeting meet = new Meeting((int)dn["ID"]);//יוצר פגישה לפי שורת הפגישה במסד הנתונים
                    DataRow de = dt.NewRow();//יוצר שורה חדשה לפי תנאי הטבלת נתונים שבניתי בתחילה
                    //ממלא את שורת הנתונים כמו שצריך
                    de["ID"] = meet.GetID();
                    de["Student"] = meet.תלמיד;
                    de["Teacher"] = meet.מורה;
                    de["Subject"] = meet.נושא;
                    de["Hour"] = meet.שעה;
                    de["Date"] = meet.תאריך;
                    dt.Rows.Add(de);//מעדכן את טבלת הנתונים בטבלה
                }
            }
            ds.Tables.Add(dt);//מוסיף את טבלת הנתונים לסט הנתונים שיצרתי
            return ds;//מחזיר את סט הנתונים שבניתי בהתחלה
        }
    }
}
