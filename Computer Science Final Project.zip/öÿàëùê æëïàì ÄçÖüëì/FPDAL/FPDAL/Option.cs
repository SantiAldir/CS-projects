﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FPDAL
{
    public sealed class Option
    {
        private int id;
        private string view;
        public Option(int id, string view)
        {
            this.id = id;
            this.view = view;
        }
        public int ID
        {
            get
            {
                return this.id;
            }
        }
        public override string ToString()
        {
            return this.view;
        }
    }
}
