﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace FPDAL
{
    public class oleDBhelper
    {
        private static string connection=@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\פרויקט סיכום מחשבים\FPDAL\FPDAL\bin\Debug\PrivateLessonsFinalProj.accdb";
        public static DataSet fill(string cmd)
        {
            DataSet ds = new DataSet();
            OleDbConnection cn = new OleDbConnection(connection);
            OleDbCommand command = new OleDbCommand();
            command.Connection = cn;
            command.CommandText = cmd;
            OleDbDataAdapter adapter = new OleDbDataAdapter(command);
            try
            {
                adapter.Fill(ds);
            }
            catch(Exception e)
            {
                string s = e.Message;
            }
            return ds;
        }
        //פעולה לעדכון הDB
        public static void update(DataSet ds, string cmd)
        {
            OleDbConnection cn = new OleDbConnection(connection);
            OleDbCommand command = new OleDbCommand();
            command.Connection = cn;
            command.CommandText = cmd;
            OleDbDataAdapter adapter = new OleDbDataAdapter(command);
            OleDbCommandBuilder builder = new OleDbCommandBuilder(adapter);
            try
            {
                adapter.InsertCommand = builder.GetInsertCommand();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            try
            {
                adapter.DeleteCommand = builder.GetDeleteCommand();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            try
            {
                adapter.UpdateCommand = builder.GetUpdateCommand();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            try
            {
                adapter.Update(ds);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
