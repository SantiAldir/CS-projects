﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FPDAL
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("are you sure?");
            char c = char.Parse(Console.ReadLine());
            if (c == 'y')
            {
                Console.WriteLine(Teacher.SetMeeting(2, "2012/04/20", "17:00"));
            }
        }
    }
}
