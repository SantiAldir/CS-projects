﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FPDAL
{
    public class HomeWork
    {
        private string subject;
        private string Description;
        public HomeWork(int homework)
        {
            DataSet ds = oleDBhelper.fill("Select * from HomeWork where ID=" + homework);
            DataRow dr = ds.Tables[0].Rows[0];
            this.Description = dr["Description"].ToString();
            int sub = (int)dr["SubjectNum"];
            ds = oleDBhelper.fill("Select * From LevelSubjects where ID=" + sub);
            dr = ds.Tables[0].Rows[0];
            subject = oleDBhelper.fill("Select * From Globalsubjects where ID=" + dr["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + dr["LevelSub"].ToString();
        }
        public string נושא
        {
            get
            {
                return this.subject;
            }
        }
        public string שיעורים
        {
            get
            {
                return this.Description;
            }
        }
    }
}
