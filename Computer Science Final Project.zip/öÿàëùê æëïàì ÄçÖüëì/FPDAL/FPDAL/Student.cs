﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FPDAL
{
    public class Student
    {
        private string name;
        private string Phone;
        private string mail;
        public Student(int ID)
        {
            DataSet ds = oleDBhelper.fill("Select * From Students where ID=" + ID);
            DataRow dr = ds.Tables[0].Rows[0];
            this.name = dr["PName"].ToString() + " " + dr["LName"].ToString();
            this.Phone = dr["PhoneNumber"].ToString();
            this.mail = dr["Email"].ToString();
        }
        public Student()
        {
        }
        public void Set_Me(int ID)
        {
            Student s = new Student(ID);
            this.mail = s.mail;
            this.name = s.name;
            this.Phone = s.Phone;
        }
        public string שם
        {
            get
            {
                return this.name;
            }
        }
        public string טלפון
        {
            get
            {
                return this.Phone;
            }
        }
        public string אימייל
        {
            get
            {
                return this.mail;
            }
        }

        public static DataRow Add(string pname, string lname, string password, string phone, string mail)
        {
            DataSet ds = oleDBhelper.fill("Select * From Students where Email ='" + mail + "'");
            if (ds.Tables[0].Rows.Count != 0)
            {
                System.Windows.Forms.MessageBox.Show("יש לך משתמש");
                return null;
            }
            ds.Clear();
            ds = oleDBhelper.fill("Select * From Students");
            DataRow dr = ds.Tables[0].NewRow();
            dr["PName"] = pname;
            dr["LName"] = lname;
            dr["PassWordP"] = password.ToLower();
            dr["PhoneNumber"] = phone;
            dr["Email"] = mail;
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From Students");
            return dr;
        }
        public static void Remove(int id)
        {
            DataSet ds = oleDBhelper.fill("Select * From Students where ID=" + id);
            DataRow dr = ds.Tables[0].Rows[0];
            dr.Delete();
            oleDBhelper.update(ds,"Select * From Students");
            ds=oleDBhelper.fill("Select * From StudentTeacher where Student="+id);
            foreach(DataRow dl in ds.Tables[0].Rows)
            {
                Teacher.EndSchool((int)dl["ID"]);
            }
        }
        public static void Update(int id, string edit, object change)
        {
            DataSet ds = oleDBhelper.fill("Select * From Students where ID=" + id);
            DataRow dr = ds.Tables[0].Rows[0];
            dr[edit] = change;
            oleDBhelper.update(ds, "Select * From Studnets where ID=" + id);
        }
        public static void ChooseTeacher(int student, int subtech)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher"), dsh = oleDBhelper.fill("Select * From TechersSubjects where ID=" + subtech);
            DataRow dr = ds.Tables[0].NewRow();
            dr["Student"] = student;
            dr["Teacher"] = dsh.Tables[0].Rows[0]["Teacher"];
            dr["Subject"] = dsh.Tables[0].Rows[0]["SubjectNum"];
            dr["PricePerLesson"] = 0;
            dr["NotPaid"] = 0;
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From StudentTeacher");
        }
        public static Teacher[] MyTeachers(int Student)
        //הפעולה מקבלת מספר של תלמיד ומחזירה את כל המורים שלו
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where Student=" + Student);
            Teacher[] Teachers =new Teacher[ds.Tables[0].Rows.Count];
            int i = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                DataSet das = oleDBhelper.fill("Select * From LevelSubjects where ID="+dr["Subject"]);
                DataSet dss=oleDBhelper.fill("Select * From GlobalSubjects where ID="+das.Tables[0].Rows[0]["IDbasesub"]);
                Teachers[i] = new Teacher();
                Teachers[i].Set_Me((int)dr["Teacher"], dss.Tables[0].Rows[0]["SubName"] + " " + das.Tables[0].Rows[0]["Levelsub"]);
                i++;
            }
            return Teachers;
        }
        public static DataTable GetInvoices(int student)
        {
            DataSet ds = oleDBhelper.fill("Select * From Students where ID=" + student);
            DataRow dr = ds.Tables[0].Rows[0];
            return oleDBhelper.fill("Select * From Invoices where student='" + dr["PName"] + " " + dr["LName"] + "'").Tables[0];
        }
        public static HomeWork[] My_Homework(int student)
        {
            DataTable dt = oleDBhelper.fill("Select * From HomeWork where StudentNum=" + student).Tables[0];
            HomeWork[] hw = new HomeWork[dt.Rows.Count];
            int i = dt.Rows.Count-1;
            foreach (DataRow dr in dt.Rows)
            {
                hw[i--] = new HomeWork((int)dr["ID"]);
            }
            return hw;
        }
    }
}
