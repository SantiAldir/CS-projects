﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FPDAL
{
    public class Manager
    {
        private string name;
        private string Phone;
        private string mail;
        public Manager(int ID)
        {
            DataSet ds = oleDBhelper.fill("Select * From Managers where ID=" + ID);
            DataRow dr = ds.Tables[0].Rows[0];
            this.name = dr["PName"].ToString() + " " + dr["LName"].ToString();
            this.Phone = dr["PhoneNumber"].ToString();
            this.mail = dr["Email"].ToString();
        }
        public Manager()
        {
        }
        public void Set_me(int ID)
        {
            Manager s = new Manager(ID);
            this.mail = s.mail;
            this.name = s.name;
            this.Phone = s.Phone;
        }
        public string שם
        {
            get
            {
                return this.name;
            }
        }
        public string טלפון
        {
            get
            {
                return this.Phone;
            }
        }
        public string אימייל
        {
            get
            {
                return this.mail;
            }
        }
        public static DataRow Login(string Email, string Password, string table)
        {
            DataSet ds = oleDBhelper.fill("Select * From " + table + " where EMail='" + Email + "' and PassWordP='" + Password + "'");
            if (ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            else
            {
                return ds.Tables[0].Rows[0];
            }
        }
        public static void Add(string pname, string lname, string pass, string Phone, string email, string tbl)
        {
            string cmd = "Select * From " + tbl;
            DataSet ds = oleDBhelper.fill(cmd);
                DataRow dr = ds.Tables[0].NewRow();
            dr["PName"] = pname;
            dr["LName"] = lname;
            dr["PassWordP"] = pass;
            dr["PhoneNumber"] = Phone;
            dr["EMail"] = email;
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, cmd);
        }
        /*public static int BecomeManeger(int id, string type)
        {
            string s;
            if (type.ToLower() == "teacher")
            {
                s = "Teachers";
            }
            else
            {
                s = "Students";
            }
            DataSet ds = oleDBhelper.fill("Select * From " + s + " where ID=" + id);
            DataSet dm = oleDBhelper.fill("Select * From Managers");
            DataRow dr = ds.Tables[0].Rows[0];
            DataRow dam = dm.Tables[0].NewRow();
            dam["PassWordP"] = dr["PassWordP"];
            dam["PName"] = dr["PName"];
            dam["LName"] = dr["LName"];
            dam["PhoneNumber"] = dr["PhoneNumber"];
            dam["Email"] = dr["Email"];
            dam["Teacher"] = "no";
            dam["Student"] = "no";
            if (s == "Teachers")
            {
                dam["Teacher"] = "yes";
                s = "Students";
            }
            else
            {
                dam["Student"] = "yes";
                s = "Teachers";
            }
            if (oleDBhelper.fill("Select * From " + s + " where PhoneNumber='" + dr["PhoneNumber"] + "'").Tables[0].Rows.Count != 0)
            {
                s = s.Substring(0, s.Length - 1);
                dam[s] = "yes";
            }
            return (int)dam["ID"];
        }*/
        public static DataTable AllStudents()
        {
            return oleDBhelper.fill("Select * From Students").Tables[0];
        }
        public static DataTable AllTeachers()
        {
            return oleDBhelper.fill("Select * From Teachers").Tables[0];
        }
        public static DataTable AllManager()
        {
            return oleDBhelper.fill("Select * From Managers").Tables[0];
        }
        public static DataSet GetAllManagers()
        {
            DataSet ds = oleDBhelper.fill("Select * From Managers");
            ds.Tables[0].Columns.Remove("PassWordP");
            return ds;
        }
        public static void RemoveManager(int id)
        {
            DataSet ds = oleDBhelper.fill("Select * From Managers where ID=" + id);
            ds.Tables[0].Rows[0].Delete();
            oleDBhelper.update(ds, "Select * From Managers");
        }
        public static DataRow EditPerson(int id, string pname, string lname, string password, string phone, string mail, string table)
        {
            DataSet ds = oleDBhelper.fill("Select * From " + table + " where ID=" + id);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            DataRow dr = ds.Tables[0].Rows[0];
            dr["PName"] = pname;
            dr["PassWordP"] = password;
            dr["LName"] = lname;
            dr["PhoneNumber"] = phone;
            dr["EMail"] = mail;
            oleDBhelper.update(ds, "Select * From " + table);
            return dr; 
        }
        public static void AddGuest(string name, string mail, string phone, string way)
        {
            DataSet ds = oleDBhelper.fill("Select * From GuestsDetails");
            DataRow dr = ds.Tables[0].NewRow();
            dr["FullName"] = name;
            dr["EMail"] = mail;
            dr["PhoneNum"] = phone;
            dr["HowDidFindUs"] = way;
            dr["MadeContact"] = "no";
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From GuestsDetails");
        }
        public static DataSet GetAllNewGuests()
        {
            DataSet ds = oleDBhelper.fill("Select * From GuestsDetails where MadeContact='no'");
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            return ds;
        }
    }
}
