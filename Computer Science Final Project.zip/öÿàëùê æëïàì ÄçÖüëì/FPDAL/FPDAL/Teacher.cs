﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FPDAL
{
    public class Teacher
    {
        private string name;
        private string Phone;
        private string mail;
        private string sub;
        public Teacher(int ID, string sub)
        {
            DataSet ds = oleDBhelper.fill("Select * From Teachers where ID=" + ID);
            DataRow dr = ds.Tables[0].Rows[0];
            this.name = dr["PName"].ToString() + " " + dr["LName"];
            this.Phone = dr["PhoneNumber"].ToString();
            this.mail = dr["Email"].ToString();
            this.sub = sub;
        }
        public Teacher()
        {
        }
        public void Set_Me(int ID, string sub)
        {
            Teacher tc = new Teacher(ID, sub);
            this.mail = tc.mail;
            this.name = tc.name;
            this.Phone = tc.Phone;
            this.sub = tc.sub;
        }
        public string שם
        {
            get
            {
                return this.name;
            }
        }
        public string טלפון
        {
            get
            {
                return this.Phone;
            }
        }
        public string אימייל
        {
            get
            {
                return this.mail;
            }
        }
        public string נושא
        {
            get
            {
                return this.sub;
            }
        }
        public static DataRow Add(string pname, string lname, string password, string phone, string mail)
        {
            DataSet ds = oleDBhelper.fill("Select * from Teachers where Email = '" + mail + "'");
            if (ds.Tables[0].Rows.Count != 0)
            {
                System.Windows.Forms.MessageBox.Show("אתה קיים במערכת");
                return null;
            }
            ds = oleDBhelper.fill("Select * From Teachers");
            DataRow dr = ds.Tables[0].NewRow();
            dr["PName"] = pname;
            dr["LName"] = lname;
            dr["PassWordP"] = password;
            dr["PhoneNumber"] = phone;
            dr["Email"] = mail;
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From Teachers");
            return dr;
        }
        public static void Remove(int id)
        {
            DataSet ds = oleDBhelper.fill("Select * From Teachers where ID =" + id);
            DataRow dr = ds.Tables[0].Rows[0];
            dr.Delete();
            oleDBhelper.update(ds, "Select * From Teachers");
            ds = oleDBhelper.fill("Select from TechersSubjects where Teacher=" + id);
            foreach(DataRow dl in ds.Tables[0].Rows)
            {
                StopTeaching((int)dl["ID"]);
            }
        }
        public static void Update(int id, string edit, object change)
        {
            DataSet ds=oleDBhelper.fill("Select *  From Techers where ID="+id);
            DataRow dr = ds.Tables[0].Rows[0];
            dr[edit] = change;
        }
        public static void GiveHomework(int student, string homework, int subject)
        {
            DataSet ds = oleDBhelper.fill("Select * From HomeWork");
            DataRow dr = ds.Tables[0].NewRow();
            dr["StudentNum"] = student;
            dr["SubjectNum"] = subject;
            dr["Description"] = homework;
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From HomeWork");
        }
        public static void ChooseSubject(int teacher, int subject)
        {
            DataSet ds = oleDBhelper.fill("Select * From TechersSubjects");
            DataRow dr = ds.Tables[0].NewRow();
            dr["Teacher"] = teacher;
            dr["SubjectNum"] = subject;
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From TechersSubjects");
        }
        public static void SetPrice(int price, int studteach)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where ID=" + studteach);
            ds.Tables[0].Rows[0]["PricePerLesson"] = price;
            oleDBhelper.update(ds, "Select * From StudentTeacher");
        }
        public static void StopTeaching(int id)
        {
            DataSet ds = oleDBhelper.fill("Select * From TechersSubjects where ID=" + id);
            DataRow dr = ds.Tables[0].Rows[0];
            int teach = (int)dr["Teacher"];
            int sub = (int)dr["SubjectNum"];
            dr.Delete();
            oleDBhelper.update(ds, "Select * From TechersSubjects");
            DataSet dl = oleDBhelper.fill("Select * From StudentTeacher where Teacher=" + teach + " and subject=" + sub);
            foreach (DataRow dm in dl.Tables[0].Rows)
            {
                EndSchool((int)dm["ID"]);
            }
        }
        public static void EndSchool(int stuteach)
        {
            int student;
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where ID=" + stuteach);
            DataRow dr = ds.Tables[0].Rows[0];
            student = (int)dr["Student"];
            int subject = (int)dr["Subject"];
            dr.Delete();
            string sstu = oleDBhelper.fill("Select * From Students where ID=" + student).Tables[0].Rows[0]["PName"].ToString() + oleDBhelper.fill("Select * From Students where ID=" + student).Tables[0].Rows[0]["LName"].ToString();
            string ssub = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + oleDBhelper.fill("Select * From LevelSubjects where ID=" + subject).Tables[0].Rows[0]["IDbasesub"]).Tables[0].Rows[0]["SubName"] + " ברמה של " + oleDBhelper.fill("Select * From LevelSubjects where ID=" + subject).Tables[0].Rows[0]["Levelsub"];
            oleDBhelper.update(ds, "Select * From StudentTeacher");
            System.Windows.Forms.MessageBox.Show("ברכותיי! " + sstu + " סיים ללמוד " + ssub);
        }
        public static void AddRecieve(int stuteach, int pay, string way)
        {
            DataSet ds = oleDBhelper.fill("Select * From Invoices");
            DataSet dts = oleDBhelper.fill("Select * From StudentTeacher where ID=" + stuteach);
            DataRow dr = ds.Tables[0].NewRow();
            DataRow dtr = dts.Tables[0].Rows[0];
            dr["Student"] = oleDBhelper.fill("Select * From Students where ID=" + dtr["Student"]).Tables[0].Rows[0]["PName"].ToString() +" "+ oleDBhelper.fill("Select * From Students where ID=" + dtr["Student"]).Tables[0].Rows[0]["LName"];
            dr["Teacher"] = oleDBhelper.fill("Select * From Teachers where ID=" + dtr["Teacher"]).Tables[0].Rows[0]["PName"].ToString() +" "+ oleDBhelper.fill("Select * From Teachers where ID=" + dtr["Teacher"]).Tables[0].Rows[0]["LName"];
            dr["How"] = way;
            dr["Price"] = pay;
            dtr["NotPaid"] = (int)dtr["NotPaid"] - pay;
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From Invoices");
            oleDBhelper.update(dts, "Select * From StudentTeacher");
        }
        public static Student[] MyStudents(int teacher)
        //הפעולה מקבלת מספר של מורה ומחזירה את כל התלמידים שלו
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where Teacher=" + teacher);
            Student[] students = new Student[ds.Tables[0].Rows.Count];
            int i = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                students[i] = new Student();
                students[i].Set_Me((int)dr["Student"]);
                i++;
            }
            return students;
        }
        public static DataTable GetInvoices(int teacher)
        {
            DataSet ds = oleDBhelper.fill("Select * From Teachers where ID=" + teacher);
            DataRow dr = ds.Tables[0].Rows[0];
            return oleDBhelper.fill("Select * From Invoices where Teacher='" + dr["PName"] + " " + dr["LName"] + "'").Tables[0];
        }
        public static int ReportMeeting(int stutech, int meeting)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where ID=" + stutech);
            DataRow dr = ds.Tables[0].Rows[0];
            dr["NotPaid"] = (int)dr["NotPaid"] + (int)dr["PricePerLesson"];
            int ret = (int)dr["NotPaid"];
            oleDBhelper.update(ds, "Select * From StudentTeacher");
            ds = oleDBhelper.fill("Select * From Meeting where ID=" + meeting);
            dr = ds.Tables[0].Rows[0];
            dr["Happend"] = "yes";
            return ret;
        }
        public static string SetMeeting(int studteach, string date, string hour)
        {
            int pre, aft;
            DataSet ds = oleDBhelper.fill("Select * From Meeting");
            pre = ds.Tables[0].Rows.Count;
            DataRow dr = ds.Tables[0].NewRow();
            dr["MeetingDate"] = date;
            dr["MeetingHour"] = hour;
            dr["StudTeach"] = studteach;
            dr["Happend"] = "לא";
            ds.Tables[0].Rows.Add(dr);
            oleDBhelper.update(ds, "Select * From Meeting");
            aft = oleDBhelper.fill("Select * From Meeting").Tables[0].Rows.Count;
            if (pre != aft)
                return "פגישה נקבעה בהצלחה";
            return "חלה בעיה בעדכון הפגישה";
        }
    }
}
