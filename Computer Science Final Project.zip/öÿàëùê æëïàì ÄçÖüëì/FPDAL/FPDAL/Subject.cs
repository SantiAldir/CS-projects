﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FPDAL
{
    public class Subject
    {
        public static string AddSubject(string name)
        {
            string ret = "נושא הוסף בהצלחה";
            if (oleDBhelper.fill("Select* From GlobalSubjects where SubName='" + name + "'").Tables[0].Rows.Count != 0)
            {
                ret = "נושא קיים במערכת";
            }
            else
            {
                DataSet ds = oleDBhelper.fill("Select * From GlobalSubjects");
                DataRow dr = ds.Tables[0].NewRow();
                dr["SubName"] = name;
                ds.Tables[0].Rows.Add(dr);
                oleDBhelper.update(ds, "Select *From GlobalSubjects");
            }
            return ret;
        }
        public static string AddLevel(int subject, string level, string description)
        {
            string ret = "התווספה רמה חדשה לנושא";
            if (oleDBhelper.fill("Select * From LevelSubjects where IDbasesub = " + subject + " and Levelsub='" + level + "'").Tables[0].Rows.Count != 0)
            {
                ret = "רמה זו כבר קיימת לנושא";
            }
            else
            {
                DataSet ds = oleDBhelper.fill("Select * From LevelSubjects");
                DataRow dr = ds.Tables[0].NewRow();
                dr["IDbasesub"] = subject;
                dr["Levelsub"] = level;
                dr["Description"] = description;
                ds.Tables[0].Rows.Add(dr);
                oleDBhelper.update(ds, "Select * From LevelSubjects");
            }
            return ret;
        }
        public static DataTable All_Base_Subjects()
        {
            return oleDBhelper.fill("Select * From GlobalSubjects").Tables[0];
        }
        public static DataTable All_Level_Subject()
        {
            return oleDBhelper.fill("Select * From LevelSubjects").Tables[0];
        }
        public static void Remove_Subject(int subject)
        {
            DataSet Dl=oleDBhelper.fill("Select * From GlobalSubjects where ID =" + subject);
            Dl.Tables[0].Rows[0].Delete();
            oleDBhelper.update(Dl, "Select * from GlobalSubjects");
            DataSet ds = oleDBhelper.fill("Select * From LevelSubjects where IDbasesub=" + subject);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                Remove_Level((int)dr["ID"]);
            }
            oleDBhelper.update(ds, "Select * From LevelSubjects");
        }
        public static void Remove_Level(int level)
        {
            DataSet ds = oleDBhelper.fill("Select * From LevelSubjects where ID=" + level);
            ds.Tables[0].Rows[0].Delete();
            oleDBhelper.update(ds, "Select * From LevelSubjects");
            DataTable dt = oleDBhelper.fill("Select * From StudentTeacher where subject=" + level).Tables[0];
            foreach (DataRow dr in dt.Rows)
            {
                Teacher.StopTeaching((int)dr["ID"]);
            }
        }
        public static DataRow View_Base_Subject(int id)
        {
            return oleDBhelper.fill("Select * from GlobalSubjects where ID=" + id).Tables[0].Rows[0];
        }

    }
}
