﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FPDAL
{
    public class Meeting
    {
        private int id;
        private string teacher;
        private string student;
        private string subject;
        private string date;
        private string hour;
        private int subnum;
        public Meeting(int ID)
        {
            DataSet ds = oleDBhelper.fill("Select * From Meeting where ID=" + ID);
            DataRow dr = ds.Tables[0].Rows[0];
            this.id = (int)dr["ID"];
            this.date = dr["MeetingDate"].ToString();
            this.hour = dr["MeetingHour"].ToString();
            DataSet ds1 = oleDBhelper.fill("Select * From StudentTeacher where ID=" + dr["StudTeach"]);
            DataRow dr1 = ds1.Tables[0].Rows[0];
            DataSet ds2 = oleDBhelper.fill("Select * From Teachers where ID=" + dr1["Teacher"]);
            DataRow dr2 = ds2.Tables[0].Rows[0];
            this.teacher = dr2["PName"].ToString() + " " + dr2["LName"].ToString();
            ds2 = oleDBhelper.fill("Select * From Students where ID=" + dr1["Student"]);
            dr2 = ds2.Tables[0].Rows[0];
            this.student = dr2["PName"].ToString() + " " + dr2["LName"].ToString();
            ds2 = oleDBhelper.fill("Select * From LevelSubjects where ID=" + dr1["Subject"]);
            dr2 = ds2.Tables[0].Rows[0];
            this.subnum = (int)dr2["ID"];
            this.subject = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + dr2["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + " " + dr2["Levelsub"].ToString();
        }
        public string מורה
        {
            get
            {
                return this.teacher;
            }
        }
        public string תלמיד
        {
            get
            {
                return this.student;
            }
        }
        public string נושא
        {
            get
            {
                return this.subject;
            }
        }
        public string תאריך
        {
            get
            {
                return this.date;
            }
        }
        public string שעה
        {
            get
            {
                return this.hour;
            }
        }
        public int GetID()
        {
            return this.id;
        }
        public string StudentToString()
        {
            return this.student + " - " + this.subject + " : " + this.date + " - " + this.hour;
        }
        public int GetIDsub()
        {
            return this.subnum;
        }
        public override string ToString()
        {
            return this.student + " - " + this.subject + " - " + this.date + " - " + this.hour;
        }
        public static void CancelMeeting(int id)
        {
            oleDBhelper.fill("Delete * From Meeting where ID=" + id);
        }
    }
}
