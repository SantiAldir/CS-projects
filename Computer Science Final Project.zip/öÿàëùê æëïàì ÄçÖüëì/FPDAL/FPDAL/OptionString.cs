﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FPDAL
{
    public class OptionString
    {
        private string view;
        private string send;
        public OptionString(string view, string send)
        {
            this.view = view;
            this.send = send;
        }
        public override string ToString()
        {
            return this.view;
        }
        public string Send
        {
            get
            {
                return this.send;
            }
        }
    }
}
