﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class ViewStudents : Form
    {
        private int ID;
        public ViewStudents(int teachid)
        {
            this.ID = teachid;
            InitializeComponent();
        }

        private void ViewStudents_Load(object sender, EventArgs e)
        {
            if (ID == 0)
            {
                dataGridView1.DataSource = Manager.AllStudents();
            }
            else
            {
                dataGridView1.DataSource = Teacher.MyStudents(ID);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
