﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class ChooseLevelSub : Form
    {
        private DataRow User;
        public ChooseLevelSub(DataRow dr)
        {
            User = dr;
            InitializeComponent();
        }

        private void ChooseLevelSub_Load(object sender, EventArgs e)
        {
            DataTable DT = Subject.All_Level_Subject();
            foreach (DataRow dr in DT.Rows)
            {
                Option o = new Option((int)(dr["ID"]), Subject.View_Base_Subject((int)dr["IDbasesub"])["SubName"].ToString() +" " + dr["Levelsub"].ToString());
                comboBox1.Items.Add(o);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Teacher.ChooseSubject((int)User["ID"], ((Option)comboBox1.SelectedItem).ID);
            MessageBox.Show("התווסף בהצלחה");
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("הנושא הנבחר הוא: " + comboBox1.SelectedItem.ToString());
        }
    }
}
