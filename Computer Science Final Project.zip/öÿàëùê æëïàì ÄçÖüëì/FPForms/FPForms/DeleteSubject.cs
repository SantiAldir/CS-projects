﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class DeleteSubject : Form
    {
        private int type;
        public DeleteSubject(int type)
        {
            this.type = type;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem is Option)
            {
                Option o = (Option)comboBox1.SelectedItem;
                if (type == 1)
                {
                    Subject.Remove_Subject(o.ID);
                }
                else
                {
                    Subject.Remove_Level(o.ID);
                }
                MessageBox.Show("נושא נמחק בהצלחה");
                this.Close();
            }
        }

        private void DeleteSubject_Load(object sender, EventArgs e)
        {
            DataTable DT;
            int ID;
            string view;
            if (type == 1)
            {
                DT = Subject.All_Base_Subjects();
            }
            else
            {
                DT = Subject.All_Level_Subject();
            }
            foreach (DataRow dr in DT.Rows)
            {
                if (type == 1)
                {
                    ID = (int)dr["ID"];
                    view = dr["SubName"].ToString();
                }
                else
                {
                    ID=(int)dr["ID"];
                    view = Subject.View_Base_Subject((int)dr["IDbasesub"])["SubName"].ToString() + " " + dr["Levelsub"].ToString();
                }
                Option op = new Option(ID, view);
                comboBox1.Items.Add(op);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("בחרת ב " + comboBox1.SelectedItem.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
