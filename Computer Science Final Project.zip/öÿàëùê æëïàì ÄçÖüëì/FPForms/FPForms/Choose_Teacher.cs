﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Choose_Teacher : Form
    {
        private DataRow user;
        public Choose_Teacher(DataRow dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Choose_Teacher_Load(object sender, EventArgs e)
        {
            DataSet ds = oleDBhelper.fill("Select * From TechersSubjects");
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                int id = (int)dr["ID"];
                DataSet ds1 = oleDBhelper.fill("Select * From Teachers where ID=" + dr["Teacher"]);
                string tech = ds1.Tables[0].Rows[0]["PName"].ToString() + " " + ds1.Tables[0].Rows[0]["LName"].ToString();
                ds1 = oleDBhelper.fill("Select * from LevelSubjects where ID=" + dr["SubjectNum"]);
                DataRow dr1 = ds1.Tables[0].Rows[0];
                string sub = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + dr1["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + " " + dr1["Levelsub"].ToString();
                Option o = new Option(id, tech + " - " + sub);
                comboBox1.Items.Add(o);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student.ChooseTeacher((int)user["ID"], ((Option)comboBox1.SelectedItem).ID);
            MessageBox.Show("התווסף בהצלחה");
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("אתה בטוח שאתה מעוניין ב" + comboBox1.SelectedItem.ToString(), "בטוח?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                button1.Enabled = true;
            }
            else
            {
                if (res == DialogResult.No)
                {
                    button1.Enabled = false;
                }
            }
        }
    }
}
