﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FPForms
{
    public partial class Teacherfrm : Form
    {
        private DataRow user;
        public Teacherfrm(DataRow dr)//:base(dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Exist_Subjects es = new Exist_Subjects(1);
            es.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddLevel al = new AddLevel();
            al.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddPerson ap = new AddPerson("Students");
            ap.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ChooseLevelSub cls = new ChooseLevelSub(this.user);
            cls.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PayDay pd = new PayDay(user);
            pd.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Report_Meeting rm = new Report_Meeting(user);
            rm.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SetMeeting sm = new SetMeeting(user);
            sm.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Cancel_Meeting cm = new Cancel_Meeting(user);
            cm.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ViewStudents vs = new ViewStudents((int)user["ID"]);
            vs.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            GiveHomework gw = new GiveHomework(user);
            gw.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Check_My_Meetings cmm = new Check_My_Meetings(user, 1);
            cmm.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Check_recieves cr = new Check_recieves(user, 1);
            cr.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Set_Price sp = new Set_Price(user);
            sp.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Edit_Person ep = new Edit_Person("Teachers", user);
            ep.Show();
        }

    }
}
