﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class NewGuest : Form
    {
        public NewGuest()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (('א' > c || 'ת' < c) && c != ' ')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (('0' > c || '9' < c))
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
            {
                Manager.AddGuest(textBox1.Text, textBox3.Text, textBox2.Text, textBox4.Text);
            }
            else
            {
                MessageBox.Show("אנא וודא שהכנסת את כל הפרטים");
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
