﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FPForms
{
    public partial class Managerfrm : Form
    {
        private DataRow user;
        public Managerfrm(DataRow dr)//:base(dr)
        {
            this.user = dr;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewStudents vs = new ViewStudents(0);
            vs.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewTeachers vt = new ViewTeachers(0);
            vt.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewManagers vm = new ViewManagers();
            vm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Edit_Person ed = new Edit_Person("Managers", user);
            ed.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddPerson ap = new AddPerson("Managers");
            ap.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Search se = new Search(true);
            se.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DeleteSubject ds = new DeleteSubject(1);
            ds.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            DeleteSubject ds = new DeleteSubject(2);
            ds.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            AddPerson ap = new AddPerson("Teachers");
            ap.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Exist_Subjects es = new Exist_Subjects(1);
            es.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            AddLevel al = new AddLevel();
            al.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            AddPerson ap = new AddPerson("Students");
            ap.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            GuestsCheck gc = new GuestsCheck();
            gc.Show();
        }
    }
}
