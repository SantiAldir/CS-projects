﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Report_Meeting : Form
    {
        private DataRow user;
        public Report_Meeting(DataRow dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void Report_Meeting_Load(object sender, EventArgs e)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where teacher=" + user["ID"]);
            int count = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                count += oleDBhelper.fill("Select * From Meeting where StudTeach=" + dr["ID"]).Tables[0].Rows.Count;
            }
            Meeting[] meetings = new Meeting[count];
            int i = 0;
            if(count!=0)
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    DataSet ds1 = oleDBhelper.fill("Select * From Meeting where StudTeach=" + dr["ID"] +"and Happend='לא'");
                    foreach (DataRow dr1 in ds1.Tables[0].Rows)
                    {
                        meetings[i] = new Meeting((int)dr1["ID"]);
                        i++;
                    }
                }
            for (i = 0; i < meetings.Length; i++)
            {
                if (meetings[i] != null)
                    comboBox1.Items.Add(meetings[i]);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int studetnt, teacher, subject;
            string[] check = ((Meeting)comboBox1.SelectedItem).תלמיד.Split(' ');
            DataSet ds = oleDBhelper.fill("Select * From Students where PName='" + check[0] + "' and LName='" + check[1] + "'");
            studetnt = (int)ds.Tables[0].Rows[0]["ID"];
            check = ((Meeting)comboBox1.SelectedItem).מורה.Split(' ');
            ds = oleDBhelper.fill("Select * From Teachers where PName='" + check[0] + "' and LName='" + check[1] + "'");
            teacher = (int)ds.Tables[0].Rows[0]["ID"];
            check = ((Meeting)comboBox1.SelectedItem).נושא.Split(' ');
            subject = ((Meeting)comboBox1.SelectedItem).GetIDsub();
            ds = oleDBhelper.fill("Select * From StudentTeacher where student=" + studetnt + " and teacher=" + teacher + " and subject=" + subject);
            int sum = Teacher.ReportMeeting((int)ds.Tables[0].Rows[0]["ID"], ((Meeting)comboBox1.SelectedItem).GetIDsub());
            MessageBox.Show("שיעור עודכן בהצלחה");
            MessageBox.Show("התלמיד נמצא בחוב של: " + sum);
            this.Close();
        }
    }
}
