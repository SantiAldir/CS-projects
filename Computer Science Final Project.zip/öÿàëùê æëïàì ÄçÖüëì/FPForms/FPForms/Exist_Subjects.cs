﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using FPDAL;
using System.Windows.Forms;

namespace FPForms
{
    public partial class Exist_Subjects : Form
    {
        private int type;
        public Exist_Subjects(int type)
        {
            this.type = type;
            InitializeComponent();
        }

        private void Exist_Subjects_Load(object sender, EventArgs e)
        {
            if (type == 1)
            {
                button2.Enabled = true;
                button2.Visible = true;
                label2.Visible = true;
                textBox1.Visible = true;
                textBox1.Enabled = true;
            }
            dataGridView1.DataSource = Subject.All_Base_Subjects();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (oleDBhelper.fill("Select * From GlobalSubjects where SubName='" + textBox1.Text + "'").Tables[0].Rows.Count == 0)
                {
                    DialogResult res = MessageBox.Show("בחרת להוסיף " + textBox1.Text, "בטוח?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                    if (res == DialogResult.Yes)
                    {
                        Subject.AddSubject(textBox1.Text);
                        MessageBox.Show("מקצוע התווסף בהצלחה");
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("נושא קיים במערכת");
                }
            }
            else
            {
                MessageBox.Show("הכנס שם");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (c > 'ת' || c < 'א')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }
    }
}
