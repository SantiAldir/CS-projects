﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login_Page lp = new Login_Page();
            lp.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.RightToLeft = new RightToLeft();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Exist_Subjects es = new Exist_Subjects(0);
            es.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Made_Contact mc = new Made_Contact();
            mc.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Information_Page ip = new Information_Page();
            ip.Show();
        }
    }
}
