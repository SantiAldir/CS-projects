﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FPForms
{
    public partial class Studentfrm : Form
    {
        private DataRow user;
        public Studentfrm(DataRow dr)//:base(dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Check_recieves cr = new Check_recieves(user, 2);
            cr.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            My_Homework mh = new My_Homework(user);
            mh.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Check_My_Meetings cmm = new Check_My_Meetings(user, 2);
            cmm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Choose_Teacher ct = new Choose_Teacher(user);
            ct.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ViewTeachers vt = new ViewTeachers((int)user["ID"]);
            vt.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            IOU_Teacher it = new IOU_Teacher(user);
            it.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Edit_Person ep = new Edit_Person("Students", user);
            ep.Show();
        }
    }
}
