﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class AddPerson : Form
    {
        private string tbl;
        public AddPerson(string table)
        {
            this.tbl = table;
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox4.PasswordChar = '*';
            }
            else
            {
                textBox4.PasswordChar = textBox3.PasswordChar;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Manager.Add(textBox1.Text, textBox2.Text, textBox4.Text, textBox5.Text, textBox3.Text, tbl);
            MessageBox.Show("משתמש התווסף בהצלחה");
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (c > 'ת' || c < 'א')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (c < 'א' || c > 'ת')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if ((c > '9' || c < '0') && c!='-')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }
    }
}
