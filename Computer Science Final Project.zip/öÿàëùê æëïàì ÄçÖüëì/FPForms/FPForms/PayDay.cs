﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class PayDay : Form
    {
        private DataRow user;
        public PayDay(DataRow dr)
        {
            user=dr;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = 0;
            for (int i = 0; i < textBox1.Text.Length && num == 0; i++)
            {
                if (textBox1.Text[i] > '9' || textBox1.Text[i] < '0')
                {
                    num++;
                }
            }
            if (num != 0)
            {
                MessageBox.Show("תשלומים שלמים בלבד ובלי תווים!");
            }
            else
            {
                string text = "";
                text += "אתה מעוניין לגבות מ" + comboBox1.SelectedItem.ToString() + " ";
                text += "סכום של " + textBox1.Text;
                text += " באמצעות " + textBox1.Text;
                DialogResult res = MessageBox.Show(text, "בטוח?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                if (res == DialogResult.Yes)
                {
                    Teacher.AddRecieve(((Option)comboBox1.SelectedItem).ID, int.Parse(textBox1.Text), comboBox2.SelectedItem.ToString());
                    this.Close();
                }
            }
        }
        private void PayDay_Load(object sender, EventArgs e)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where Teacher=" + user["ID"]);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                DataTable dt = oleDBhelper.fill("Select * From Students where ID=" + dr["Student"]).Tables[0];
                DataRow sub = oleDBhelper.fill("Select * From LevelSubjects where ID=" + dr["Subject"]).Tables[0].Rows[0];
                string ssub = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + sub["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + sub["Levelsub"].ToString();
                Option o = new Option((int)dr["ID"], dt.Rows[0]["PName"].ToString() + " " + dt.Rows[0]["LName"].ToString()+"- "+ssub);
                comboBox1.Items.Add(o);
            }
            comboBox2.Items.Add("צק");
            comboBox2.Items.Add("מזומן");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (c > '9' || c < '0')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }
    }
}
