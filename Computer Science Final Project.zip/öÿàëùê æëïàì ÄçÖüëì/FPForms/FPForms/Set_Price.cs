﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Set_Price : Form
    {
        private DataRow user;
        public Set_Price(DataRow dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void Set_Price_Load(object sender, EventArgs e)
        {
            {
                DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where Teacher=" + user["ID"] + " and PricePerLesson=0");
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    DataTable dt = oleDBhelper.fill("Select * From Students where ID=" + dr["Student"]).Tables[0];
                    DataRow sub = oleDBhelper.fill("Select * From LevelSubjects where ID=" + dr["Subject"]).Tables[0].Rows[0];
                    string ssub = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + sub["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + sub["Levelsub"].ToString();
                    Option o = new Option((int)dr["ID"], dt.Rows[0]["PName"].ToString() + " " + dt.Rows[0]["LName"].ToString() + "- " + ssub);
                    comboBox1.Items.Add(o);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button2.Enabled = false;
            DialogResult res = MessageBox.Show("בטוח שאתה מעוניין לדכן מחיר ל:" + comboBox1.SelectedItem.ToString(), "בטוח?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                textBox1.Enabled = true;
                textBox1.Visible = true;
                label3.Visible = true;
                if (textBox1.Text != "")
                {
                    button2.Enabled = true;
                }
            }
            else
            {
                if (res == DialogResult.No)
                {
                    textBox1.Visible = false;
                    textBox1.Enabled = false;
                    label3.Visible = false;
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (c > '9' || c < '0')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
            if (textBox1.Enabled && textBox1.Text != "")
            {
                button2.Enabled = true;
            }
            else
            {
                button2.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Teacher.SetPrice(int.Parse(textBox1.Text), ((Option)comboBox1.SelectedItem).ID);
            this.Close();
        }
    }
}
