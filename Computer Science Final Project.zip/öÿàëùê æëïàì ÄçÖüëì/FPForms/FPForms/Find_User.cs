﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Find_User : Form
    {
        private bool manager;
        private DataRow user;
        private int type;
        public Find_User(DataRow dr, bool man, int type)
        {
            manager = man;
            user = dr;
            this.type = type;
            InitializeComponent();
        }

        private void Find_User_Load(object sender, EventArgs e)
        {
            button2.Enabled = manager;
            button2.Visible = manager;
            label6.Text = user["PName"].ToString();
            label7.Text = user["LName"].ToString();
            label8.Text = user["EMail"].ToString();
            label9.Text = user["PhoneNumber"].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (type == 1)
                Teacher.Remove((int)user["ID"]);
            else
                Student.Remove((int)user["ID"]);
            this.Close();
        }
    }
}
