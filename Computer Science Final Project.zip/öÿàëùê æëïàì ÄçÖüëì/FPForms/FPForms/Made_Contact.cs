﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Made_Contact : Form
    {
        public Made_Contact()
        {
            InitializeComponent();
        }

        private void Made_Contact_Load(object sender, EventArgs e)
        {
            DataSet ds = oleDBhelper.fill("Select *  From Managers");
            Manager[] managers = new Manager[ds.Tables[0].Rows.Count];
            int i = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                managers[i++] = new Manager((int)dr["ID"]);
            }
            dataGridView1.DataSource = managers;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NewGuest ng = new NewGuest();
            ng.Show();
        }
    }
}
