﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class My_Homework : Form
    {
        private DataRow user;
        public My_Homework(DataRow dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void My_Homework_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Student.My_Homework((int)user["ID"]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
