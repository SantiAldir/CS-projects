﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Cancel_Meeting : Form
    {
        private DataRow user;
        public Cancel_Meeting(DataRow dr)
        {
            this.user = dr;
            InitializeComponent();
        }

        private void Cancel_Meeting_Load(object sender, EventArgs e)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where teacher=" + user["ID"]);
            int count = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                count += oleDBhelper.fill("Select * From Meeting where StudTeach=" + dr["ID"]).Tables[0].Rows.Count;
            }
            Meeting[] meetings = new Meeting[count];
            int i = 0;
            if (count != 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    meetings[i] = new Meeting((int)(oleDBhelper.fill("Select * From Meeting where StudTeach=" + dr["ID"]).Tables[0].Rows[0]["ID"]));
                    i++;
                }
            }
            for (i = 0; i < meetings.Length; i++)
            {
                comboBox1.Items.Add(meetings[i]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string msg = "אתה בטוח שאתה רוצה לבטל את שיעור: " + ((Meeting)comboBox1.SelectedItem).StudentToString();
            DialogResult res = MessageBox.Show(msg, "בטוח?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (res == DialogResult.Yes)
            {
                Meeting.CancelMeeting(((Meeting)comboBox1.SelectedItem).GetID());
                MessageBox.Show("נושא נמחק בהצלחה");
                this.Close();
            }
            else
            {
                MessageBox.Show("בחר מה למחוק");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
