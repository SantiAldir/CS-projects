﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class ViewManagers : Form
    {
        public ViewManagers()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ViewManagers_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Manager.AllManager();
        }
    }
}
