﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Check_My_Meetings : Form
    {
        private DataRow user;
        private int tbl;
        public Check_My_Meetings(DataRow dr, int i)
        {
            this.user = dr;
            this.tbl = i;
            InitializeComponent();
        }

        private void Check_My_Meetings_Load(object sender, EventArgs e)
        {
            string table;
            if (tbl == 1)
            {
                table = "teacher";
            }
            else
            {
                table = "student";
            }
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where " + table + "=" + user["ID"]);
            int count = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                count += oleDBhelper.fill("Select * From Meeting where StudTeach=" + dr["ID"]+" and Happend='לא'").Tables[0].Rows.Count;
            }
            Meeting[] meetings = new Meeting[count];
            int i = 0;
            if (count != 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    DataSet ds1=oleDBhelper.fill("Select * From Meeting where StudTeach=" + dr["ID"] + "and Happend='לא'");
                    foreach (DataRow dr1 in ds1.Tables[0].Rows)
                    {
                        meetings[i] = new Meeting((int)(dr1["ID"]));
                        i++;
                    }
                }
            }
            dataGridView1.DataSource = meetings;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
