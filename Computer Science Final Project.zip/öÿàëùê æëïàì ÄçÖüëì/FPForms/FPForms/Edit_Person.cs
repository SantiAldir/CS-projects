﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Edit_Person : Form
    {
        private DataRow user;
        private string tbl;
        public Edit_Person(string table,DataRow dr)
        {
            tbl = table;
            user = dr;
            InitializeComponent();
        }
        public Edit_Person(string table, int id)
        {
            user = oleDBhelper.fill("Select * From" + table + " where ID=" + id).Tables[0].Rows[0];
            tbl = table;
        }

        private void Edit_Person_Load(object sender, EventArgs e)
        {
            textBox1.Text = user["PName"].ToString();
            textBox2.Text = user["LName"].ToString();
            textBox3.Text = user["PassWordP"].ToString();
            textBox5.Text = user["PhoneNumber"].ToString();
            textBox4.Text = user["EMail"].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string msg = "";
            string pname = textBox1.Text;
            msg += "שם פרטי: " + pname + "\n";
            string lname = textBox2.Text;
            msg += "שם משפחה: " + lname + "\n";
            string pass = textBox3.Text;
            msg += "סיסמה: " + pass + "\n";
            string phone = textBox4.Text;
            msg += "טלפון: " + phone + "\n";
            string mail = textBox5.Text;
            msg += "אימייל: " + mail;
            DialogResult res = MessageBox.Show(msg,"בטוח?" ,MessageBoxButtons.YesNo, MessageBoxIcon.Question ,MessageBoxDefaultButton.Button1);
            if (res == DialogResult.Yes)
            {
                if (pname == "")
                {
                    pname = user["PName"].ToString();
                }
                else
                {
                    user["PName"] = pname;
                }
                if (lname == "")
                {
                    lname = user["LName"].ToString();
                }
                else
                {
                    user["LName"] = lname;
                }
                if (pass == "")
                {
                    pass = user["PassWordP"].ToString();
                }
                else
                {
                    user["PassWordP"] = pass;
                }
                if (phone == "")
                {
                    phone = user["PhoneNumber"].ToString();
                }
                else
                {
                    user["PhoneNumber"] = phone;
                }
                if (mail == "")
                {
                    mail = user["EMail"].ToString();
                }
                else
                {
                    user["EMail"] = mail;
                }
                Manager.EditPerson((int)user["ID"], pname, lname, pass, phone, mail, tbl);
                this.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (c < 'א' || c > 'ת')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (c < 'א' || c > 'ת')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if ((c > '9' || c < '0')&&c!='-')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
