﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class SetMeeting : Form
    {
        private DataRow user;
        public SetMeeting(DataRow dr)
        {
            user = dr;
            InitializeComponent();
        }
        private static void setCombo(int length, ComboBox c)
        {
            for (int i = 0; i < length; i++)
            {
                string insert = "";
                if (i < 10)
                {
                    insert += '0';
                }
                c.Items.Add(insert + i);
            }
        }

        private void SetMeeting_Load(object sender, EventArgs e)
        {
            setCombo(24, comboBox2);
            setCombo(60, comboBox3);
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where Teacher=" + user["ID"]);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                DataTable dt = oleDBhelper.fill("Select * From Students where ID=" + dr["Student"]).Tables[0];
                DataRow sub = oleDBhelper.fill("Select * From LevelSubjects where ID=" + dr["Subject"]).Tables[0].Rows[0];
                string ssub = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + sub["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + sub["Levelsub"].ToString();
                Option o = new Option((int)dr["ID"], dt.Rows[0]["PName"].ToString() + " " + dt.Rows[0]["LName"].ToString() + "- " + ssub);
                comboBox1.Items.Add(o);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string msg=Teacher.SetMeeting(((Option)comboBox1.SelectedItem).ID, dateTimePicker1.Value.ToString("yyyy/MM/dd"), comboBox2.SelectedItem.ToString() + ":" + comboBox3.SelectedItem.ToString());
            MessageBox.Show(msg);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
