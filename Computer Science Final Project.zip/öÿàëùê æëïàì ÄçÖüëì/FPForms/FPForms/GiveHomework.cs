﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class GiveHomework : Form
    {
        private DataRow user;
        public GiveHomework(DataRow dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("הפרטים כולם נכונים?", "בטוח?", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                int stuteach = ((Option)comboBox1.SelectedItem).ID;
                DataSet ds = oleDBhelper.fill("Select * from StudentTeacher where ID=" + stuteach);
                int student = (int)ds.Tables[0].Rows[0]["Student"];
                int subject = (int)ds.Tables[0].Rows[0]["Subject"];
                Teacher.GiveHomework(student, textBox1.Text, subject);
                MessageBox.Show("שיעורים ניתנו בהצלחה");
                this.Close();
            }
            else
            {
                MessageBox.Show("בחר את מה שאתה צריך");
            }
        }

        private void GiveHomework_Load(object sender, EventArgs e)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where Teacher=" + user["ID"]);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                DataTable dt = oleDBhelper.fill("Select * From Students where ID=" + dr["Student"]).Tables[0];
                DataRow sub = oleDBhelper.fill("Select * From LevelSubjects where ID=" + dr["Subject"]).Tables[0].Rows[0];
                string ssub = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + sub["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + sub["Levelsub"].ToString();
                Option o = new Option((int)dr["ID"], dt.Rows[0]["PName"].ToString() + " " + dt.Rows[0]["LName"].ToString() + "- " + ssub);
                comboBox1.Items.Add(o);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
