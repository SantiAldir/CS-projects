﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class IOU_Teacher : Form
    {
        private DataRow user;
        public IOU_Teacher(DataRow dr)
        {
            user = dr;
            InitializeComponent();
        }

        private void IOU_Teacher_Load(object sender, EventArgs e)
        {
            DataSet ds = oleDBhelper.fill("Select * From StudentTeacher where Student=" + user["ID"]);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                DataTable dt = oleDBhelper.fill("Select * From Teachers where ID=" + dr["Teacher"]).Tables[0];
                DataRow sub = oleDBhelper.fill("Select * From LevelSubjects where ID=" + dr["Subject"]).Tables[0].Rows[0];
                string ssub = oleDBhelper.fill("Select * From GlobalSubjects where ID=" + sub["IDbasesub"]).Tables[0].Rows[0]["SubName"].ToString() + sub["Levelsub"].ToString();
                Option o = new Option((int)dr["ID"], dt.Rows[0]["PName"].ToString() + " " + dt.Rows[0]["LName"].ToString() + "- " + ssub);
                comboBox1.Items.Add(o);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int depth = (int)oleDBhelper.fill("Select * From StudentTeacher where ID=" + ((Option)comboBox1.SelectedItem).ID).Tables[0].Rows[0]["NotPaid"];
            MessageBox.Show("אתה חייב ל" + comboBox1.SelectedItem.ToString() + ": " + depth);
        }
    }
}
