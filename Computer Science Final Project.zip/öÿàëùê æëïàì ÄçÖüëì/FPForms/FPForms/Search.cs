﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Search : Form
    {
        bool manager;
        public Search(bool manage)
        {
            manager = manage;
            InitializeComponent();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            OptionString op = new OptionString("שם פרטי", "PName");
            comboBox1.Items.Add(op);
            op = new OptionString("שם משפחה", "LName");
            comboBox1.Items.Add(op);
            op = new OptionString("אימייל", "EMail");
            comboBox1.Items.Add(op);
            op = new OptionString("תלמידים", "Students");
            comboBox2.Items.Add(op);
            op = new OptionString("מורים", "Teachers");
            comboBox2.Items.Add(op);
            button2.Enabled = manager;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text != "סוג משתמש" && comboBox1.Text != "חפש לפי" && textBox1.Text != "")
            {
                DataSet ds = oleDBhelper.fill("Select * From " + ((OptionString)comboBox2.SelectedItem).Send + " where " + ((OptionString)comboBox1.SelectedItem).Send + "='" + textBox1.Text + "'");
                if (ds.Tables[0].Rows.Count != 0)
                {
                    int type = 2;
                    DataRow dr = ds.Tables[0].Rows[0];
                    if (((OptionString)comboBox2.SelectedItem).Send == "Teachers")
                    {
                        type = 1;
                    }
                    Find_User fd = new Find_User(dr, manager, type);
                    fd.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("משתמש לא נמצא");
                }
            }
            else
            {
                MessageBox.Show("וודא שהכנסת את כל הפרטים");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataRow dr = oleDBhelper.fill("Select * From " + ((OptionString)comboBox2.SelectedItem).Send + " where " + ((OptionString)comboBox1.SelectedItem).Send + "='" + textBox1.Text + "'").Tables[0].Rows[0];
            Edit_Person ep = new Edit_Person(((OptionString)comboBox2.SelectedItem).Send, dr);
            ep.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
