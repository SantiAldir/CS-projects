﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class GuestsCheck : Form
    {
        DataSet ds;
        public GuestsCheck()
        {
            InitializeComponent();
        }

        private void GuestsCheck_Load(object sender, EventArgs e)
        {
            DataSet ds = Manager.GetAllNewGuests();
            if (ds == null)
            {
                MessageBox.Show("אין אנשים חדשים");
                this.Close();
            }
            CheckBox c=new CheckBox();
            this.ds = ds;
            ds.Tables[0].Columns.Add("SpokeWith", c.GetType());
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool[] barr = new bool[ds.Tables[0].Rows.Count];
            int i = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                barr[i]=((CheckBox)dr["SpokeWith"]).Checked;
                i++;
            }
            i=0;
            ds.Tables[0].Columns.Remove("SpokeWith");
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (barr[i])
                    dr["MadeContact"] = "yes";
            }
            oleDBhelper.update(ds, "Select * From GuestsDetails");
            this.Close();
        }
    }
}
