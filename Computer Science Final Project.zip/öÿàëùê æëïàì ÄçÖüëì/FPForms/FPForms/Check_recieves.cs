﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FPDAL;

namespace FPForms
{
    public partial class Check_recieves : Form
    {
        private DataRow user;
        private int type;
        public Check_recieves(DataRow dr, int type)
        {
            this.type = type;
            this.user = dr;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Check_recieves_Load(object sender, EventArgs e)
        {
            if (type == 1)
            {
                dataGridView1.DataSource = Teacher.GetInvoices((int)user["ID"]);
            }
            else
            {
                dataGridView1.DataSource = Student.GetInvoices((int)user["ID"]);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
