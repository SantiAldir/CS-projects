﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace FPSite
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            Response.Redirect("MadeContact.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add_Guest.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            FPWS.Service1 s=new FPSite.FPWS.Service1();
            if (TextBox1.Text == "" || TextBox2.Text == "")
            {
                Response.Write("<script>alert('אנא ממך מלא את כל הפרטים')</script>");
            }
            else
            {
                if (s.Login(TextBox1.Text, TextBox2.Text, DropDownList2.SelectedItem.Value) == 0)
                {
                    Response.Write("<script>alert('משתמש לא נמצא')</script>");
                }
                else
                {
                    Session["ID"] = s.Login(TextBox1.Text, TextBox2.Text, DropDownList2.SelectedItem.Value);
                    Session["Type"] = DropDownList2.SelectedItem.Value.Substring(0, DropDownList2.SelectedItem.Value.Length - 1);
                    Response.Redirect("MyMeetings.aspx");
                }
            }
        }
    }
}
