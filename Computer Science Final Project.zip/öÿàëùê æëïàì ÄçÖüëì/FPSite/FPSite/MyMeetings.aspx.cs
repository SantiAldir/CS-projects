﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace FPSite
{
    public partial class MyMeetings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            FPWS.Service1 s = new FPSite.FPWS.Service1();
            GridView1.DataSource = s.ViewMeetings((int)Session["ID"], Session["Type"].ToString());
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["ID"] = "";
            Session["Type"] = "";
            Response.Redirect("Default.aspx");
        }
    }
}
