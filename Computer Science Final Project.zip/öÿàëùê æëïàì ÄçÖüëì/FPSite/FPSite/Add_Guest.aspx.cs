﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace FPSite
{
    public partial class Add_Guest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            FPWS.Service1 s = new FPSite.FPWS.Service1();
            if (TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "" && TextBox4.Text != "")
            {
                s.AddGuest(TextBox1.Text, TextBox3.Text, TextBox2.Text, TextBox4.Text);
                Response.Write("<script>alert('התווספת בהצלחה')</script>");
                Response.Redirect("Default.aspx");
            }
            else
            {
                Response.Write("<script>alert('אנא הכנס את כל הפרטים!')</script>");
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if (('א' > c || 'ת' < c)&&c!=' ')
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            for (int i = 0; i < t.Text.Length; i++)
            {
                char c = t.Text[i];
                if ('0' > c || '9' < c)
                {
                    t.Text = t.Text.Remove(i, 1);
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}
